package ejemplo;

public class Bienvenida {
	public static void main(String[] args) {
		System.out.println("Hola mundo!");
		
	}
}
